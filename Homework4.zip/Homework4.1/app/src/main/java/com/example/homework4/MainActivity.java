package com.example.homework4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void bookMyTrip(View v){
        Spinner wonderChoice = (Spinner) findViewById(R.id.chosenwonder);
        String spinnerSelectedValue = wonderChoice.getSelectedItem().toString();

        RadioGroup rgTime = (RadioGroup) findViewById(R.id.lengthOfTime);
        int checkRadioButtonTime = rgTime.getCheckedRadioButtonId();
        String whichRadioButtonTime = "";
        if (checkRadioButtonTime == R.id.fourDays){
            whichRadioButtonTime = "Four Days";
        }
        else if(checkRadioButtonTime == R.id.one_week){
            whichRadioButtonTime = "One Week";
        }
        else if(checkRadioButtonTime == R.id.two_weeks){
            whichRadioButtonTime = "Two Weeks";
        }
        else if(checkRadioButtonTime == R.id.one_month){
            whichRadioButtonTime = "One Month";
        }

        RadioGroup rgPackages = (RadioGroup) findViewById(R.id.packages);
        int checkRadioButtonPackages = rgPackages.getCheckedRadioButtonId();
        String whichRadioButtonPackages = "";
        if (checkRadioButtonPackages == R.id.standard){
            whichRadioButtonPackages = "Standard";
        }
        else if(checkRadioButtonPackages == R.id.deluxe){
            whichRadioButtonPackages = "Deluxe";
        }
        else if(checkRadioButtonPackages == R.id.first_class){
            whichRadioButtonPackages = "First Class";
        }

        CheckBox locationAir = (CheckBox) findViewById(R.id.air);
        CheckBox locationWater = (CheckBox) findViewById(R.id.airAndWater);
        String possibleModes = "";

        if (locationAir.isChecked()){
            possibleModes = "Possible mode(s) of travel is Air ";
        }
        if (locationWater.isChecked()){
            if(possibleModes.length() == 0){
                possibleModes += "Possible mode(s) of travel is Air and Water.";
            }
            else{
                possibleModes += " or Air and Water.";
            }
        }
        if(possibleModes.length() == 0){
            possibleModes += "No possible mode(s) of travel were selected.";
        }

        TextView tv = (TextView) findViewById(R.id.result);
        tv.setText("The chosen wonder is " + spinnerSelectedValue + " and you will be visiting for " + whichRadioButtonTime
                + " and will be using the " + whichRadioButtonPackages + " package. " + possibleModes);
    }
}