package com.example.homework9.ui.slideshow;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.homework9.R;
import com.example.homework9.databinding.FragmentSlideshowBinding;

public class SlideshowFragment extends Fragment {

    private FragmentSlideshowBinding binding;
    private View root;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SlideshowViewModel slideshowViewModel =
                new ViewModelProvider(this).get(SlideshowViewModel.class);

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        ImageButton btn = (ImageButton) root.findViewById(R.id.recordHere);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView tv = (TextView) root.findViewById(R.id.result);
                EditText userinput = (EditText) root.findViewById(R.id.minutes);
                String minutesString = userinput.getText().toString();
                double minutesVal = Double.parseDouble(minutesString);

                do{
                    if(minutesVal <= 0){
                        userinput = (EditText) root.findViewById(R.id.minutes);
                        minutesString = userinput.getText().toString();
                        minutesVal = Double.parseDouble(minutesString);
                        tv.setText("Please input a positive integer");
                    }
                }while(minutesVal <= 0);

                Spinner actChoice = (Spinner) root.findViewById(R.id.activitiesSpinner);
                String selectedAct = actChoice.getSelectedItem().toString();

                RadioGroup rgTime = (RadioGroup) root.findViewById(R.id.weight);
                int checkRadioButtonTime = rgTime.getCheckedRadioButtonId();

                String selectedRadioButton = "";
                if (checkRadioButtonTime == R.id.onetwentyfour){
                    selectedRadioButton = "lbs124";
                }
                else if(checkRadioButtonTime == R.id.onefifty){
                    selectedRadioButton = "lbs150";
                }
                else if(checkRadioButtonTime == R.id.oneseventyfive){
                    selectedRadioButton = "lbs175";
                }
                else if(checkRadioButtonTime == R.id.twohundred){
                    selectedRadioButton = "lbs200";
                }
                else if(checkRadioButtonTime == R.id.twofifty){
                    selectedRadioButton = "lbs250";
                }

                double calories = 0.0;

                try {
                    SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                            "/data/data/" + getActivity().getPackageName() + "/databases/exercises.sqlite",
                            null,
                            SQLiteDatabase.OPEN_READONLY);


                    String query = "SELECT " + selectedRadioButton + " FROM activities WHERE exerciseactivity LIKE '" + selectedAct + "' ;";

                    tv.setText(query);

                    Cursor crs = myDB.rawQuery(query, null);

                    if(crs.moveToFirst()) {
                        do {
                            calories = crs.getDouble(0);
                        } while (crs.moveToNext());
                    }

                    calories = calories * (minutesVal/10);

                    tv.setText(calories + "");

                    myDB.close();

                    // Second database starts here

                    SQLiteDatabase myAddDB = SQLiteDatabase.openDatabase(
                            "/data/data/" + getActivity().getPackageName() +
                                    "/databases/myactivities.db",
                            null,
                            SQLiteDatabase.OPEN_READWRITE);

                    String insertSQL = "INSERT INTO acts (activity, cals) " + " VALUES ('" + selectedAct + "'," + calories + ");" ;

                    myAddDB.execSQL(insertSQL);

                    myAddDB.close();
                }   catch (Exception e) {
                    tv.setText("OOPs something is wrong");
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}