package com.example.selectioninputsdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void process_input(View v){
        Spinner monthChoice = (Spinner) findViewById(R.id.chosenmonth);
        String spinnerSelectedValue = monthChoice.getSelectedItem().toString();

        RadioGroup rg = (RadioGroup) findViewById(R.id.time_day);
        int checkRadioButton = rg.getCheckedRadioButtonId();
        String whichRadioButton = "";
        if (checkRadioButton == R.id.morning){
            whichRadioButton = "Morning";
        }
        else if(checkRadioButton == R.id.afternoon){
            whichRadioButton = "Afternoon";
        }

        CheckBox locationNorth = (CheckBox) findViewById(R.id.north);
        CheckBox locationSouth = (CheckBox) findViewById(R.id.south);
        CheckBox locationEast = (CheckBox) findViewById(R.id.east);
        CheckBox locationWest = (CheckBox) findViewById(R.id.west);
        String possibleLocations = "";

        if (locationNorth.isChecked()){
            possibleLocations = "Possible location(s) is North ";
        }
        if (locationSouth.isChecked()){
            if(possibleLocations.length() == 0){
                possibleLocations += "Possible location(s) is South";
            }
            else{
                possibleLocations += " or South";
            }
        }
        if (locationEast.isChecked()){
            if(possibleLocations.length() == 0){
                possibleLocations += "Possible location(s) is East";
            }
            else{
                possibleLocations += " or East";
            }
        }
        if (locationWest.isChecked()){
            if(possibleLocations.length() == 0){
                possibleLocations += "Possible location(s) is West";
            }
            else{
                possibleLocations += " or West";
            }
        }
        if(possibleLocations.length() == 0){
            possibleLocations += "No possible location(s) were selected";
        }

        TextView tv = (TextView) findViewById(R.id.checker);
        tv.setText("Chosen month is " + spinnerSelectedValue + " and time of day is " + whichRadioButton + ". " + possibleLocations);
        tv.setVisibility(View.VISIBLE);

        // Pass the user selections to the next activity
        Intent nextActivity = new Intent(this, MainActivity2.class);
        // passing info to MainActivity2

        nextActivity.putExtra("monthname", spinnerSelectedValue);
        nextActivity.putExtra("timeofday", whichRadioButton);
        nextActivity.putExtra("locations", possibleLocations);
        startActivity(nextActivity);
    }
}