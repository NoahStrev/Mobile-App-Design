package com.example.selectioninputsdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intentObj = getIntent();
        if (intentObj != null){
            // get data that has been passed
            String monthSelection = intentObj.getStringExtra("monthname");
            String timeofDay = intentObj.getStringExtra("timeofday");
            String selectedLocations = intentObj.getStringExtra("locations");

            String imagefilename = monthSelection.toLowerCase();
            ImageView monthimage = (ImageView) findViewById(R.id.monthimage);
            int xid = getResources().getIdentifier(getPackageName() +
                    ":drawable/" + imagefilename, null, null);
            monthimage.setImageResource(xid);

            String [] monthArray = getResources().getStringArray(R.array.seminar_months);
            String [] monthFacts = getResources().getStringArray(R.array.monthfacts);

            TextView tvmonthfact = (TextView) findViewById(R.id.monthfacts);
            for (int i = 0; i < monthArray.length; i++){
                if (monthArray[i].equals(monthSelection)){
                    tvmonthfact.setText(monthFacts[i]);
                }
            }

            // display Time of day preference and locations preferences
            TextView tv = (TextView) findViewById(R.id.confirmdata);
            tv.setText(selectedLocations + " in the " + timeofDay);
        }
    }

    public void goBack(View v){
        Intent prevActivity = new Intent(this,MainActivity.class);
        startActivity(prevActivity);
    }

    public void lastscreen(View v){
        Intent finalActivity = new Intent(this,MainActivity3.class);
        startActivity(finalActivity);
    }
}