package com.example.sharedprefsdemo;

import static android.database.sqlite.SQLiteDatabase.CREATE_IF_NECESSARY;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.view.View;
import android.widget.TextView;


public class Bookadd extends AppCompatActivity {
    // public static final int CREATE_IF_NECESSARY = 268435456;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookadd);
 //   }
 //   public void addbook(View v) {
        SQLiteDatabase myDB = null;
        String TableName = "booksimple";
        String insertSQL = "000";
        TextView tv = (TextView) findViewById(R.id.debugging);

        // Create the database if it does not exist
        try {
            tv.setText("got here 0");
            myDB = this.openOrCreateDatabase("simplebooks1.db",
                                              Context.MODE_PRIVATE,
                                             null);
            tv.setText("got here 1");
            // CREATE THE TABLE IF NECESSARU
            myDB.execSQL("CREATE TABLE IF NOT EXISTS " + TableName +
                         " (Title VARCHAR, Author VARCHAR, Year INT);" );
            tv.setText("got here 2");
        }
        catch(SQLiteException e)  {
            tv.setText("TROUBLES :(");
        }


    }











}