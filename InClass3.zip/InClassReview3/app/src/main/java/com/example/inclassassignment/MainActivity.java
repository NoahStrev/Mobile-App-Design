package com.example.inclassassignment;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sellBtn(View v){
        Spinner wonderChoice = (Spinner) findViewById(R.id.chosenflavor);
        String flavor_selected_from_spinner = wonderChoice.getSelectedItem().toString();

        RadioGroup rgTime = (RadioGroup) findViewById(R.id.size);
        int checkRadioButtonTime = rgTime.getCheckedRadioButtonId();

        String selected_radio_button_size_value = "";
        if (checkRadioButtonTime == R.id.small){
            selected_radio_button_size_value = "12";
        }
        else if(checkRadioButtonTime == R.id.large){
            selected_radio_button_size_value = "16";
        }

        Double price = 0.0;

        TextView tv = (TextView) findViewById(R.id.result);

        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() + "/databases/flavoredcoffees.sqlite",
                    null,
                    SQLiteDatabase.OPEN_READONLY);


            String query = "SELECT Price FROM Table1 "  +
                    "WHERE Flavor LIKE '" + flavor_selected_from_spinner +
                    "' AND Size = '" + selected_radio_button_size_value + "' ;" ;

            tv.setText(query);

            Cursor crs = myDB.rawQuery(query, null);

            if(crs.moveToFirst()) {
                do {
                    price = crs.getDouble(0);
                } while (crs.moveToNext());
            }

            tv.setText(price + "");

            myDB.close();
        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");
        }
    }
}