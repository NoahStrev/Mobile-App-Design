package com.example.navdrawerdemo2.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import com.example.navdrawerdemo2.R;
import com.example.navdrawerdemo2.databinding.FragmentGalleryBinding;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        GalleryViewModel galleryViewModel =
                new ViewModelProvider(this).get(GalleryViewModel.class);

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //copied and pasted this code
        String dbinfo = "";
        TextView tv = (TextView) root.findViewById(R.id.displayinfo);
        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getActivity().getPackageName() +
                            "/databases/simplebooks1.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display
            String sql = "SELECT * FROM booksimple;";
            Cursor crs = myDB.rawQuery(sql, null);

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    dbinfo += crs.getString(0) + "  " +
                            crs.getString(1) + "  " +
                            crs.getInt(2) + "\n\n";
                } while (crs.moveToNext());
            }
            tv.setText(dbinfo);
            myDB.close();
        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");

        }


        /*final TextView textView = binding.textGallery;
        galleryViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);*/
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}