package com.example.navdrawerdemo2;

import androidx.lifecycle.ViewModel;

public class WebAccessViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}