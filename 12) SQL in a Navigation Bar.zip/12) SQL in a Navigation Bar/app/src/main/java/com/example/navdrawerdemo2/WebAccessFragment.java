package com.example.navdrawerdemo2;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.navdrawerdemo2.databinding.FragmentWebAccessBinding;

public class WebAccessFragment extends Fragment {

    private WebAccessViewModel mViewModel;
    private FragmentWebAccessBinding binding;

    public static WebAccessFragment newInstance() {
        return new WebAccessFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentWebAccessBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        WebView myWebView = (WebView) root.findViewById(R.id.displayweb);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        myWebView.setWebViewClient(new WebViewClient());
        myWebView.loadUrl("https://www.carrollu.edu/");
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(WebAccessViewModel.class);
        // TODO: Use the ViewModel
    }

}