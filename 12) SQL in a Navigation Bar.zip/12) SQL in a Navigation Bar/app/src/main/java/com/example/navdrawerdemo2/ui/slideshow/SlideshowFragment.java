package com.example.navdrawerdemo2.ui.slideshow;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.view.View.OnClickListener;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.navdrawerdemo2.R;
import com.example.navdrawerdemo2.databinding.FragmentSlideshowBinding;

public class SlideshowFragment extends Fragment implements OnClickListener{

    private FragmentSlideshowBinding binding;
    private View root;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SlideshowViewModel slideshowViewModel =
                new ViewModelProvider(this).get(SlideshowViewModel.class);

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        root = binding.getRoot();

        //final TextView textView = binding.textSlideshow;
        //slideshowViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        ImageButton btn = (ImageButton) root.findViewById(R.id.btnAddBook);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView tv = (TextView) root.findViewById(R.id.debugging);

                try {
                    SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                            "/data/data/" + getActivity().getPackageName() +
                                    "/databases/simplebooks1.db",
                            null,
                            SQLiteDatabase.OPEN_READWRITE);
                    // now get data to display


                    EditText bt = (EditText) root.findViewById(R.id.inputTitle);
                    EditText ba = (EditText) root.findViewById(R.id.inputAuthor);
                    EditText by = (EditText) root.findViewById(R.id.inputYear);

                    //year as an integer
                    String btitle = bt.getText().toString();
                    String bauthor = ba.getText().toString();
                    String year = by.getText().toString();
                    int byear = Integer.parseInt(year);

                    String sql = "INSERT INTO booksimple (TITLE, AUTHOR, YEAR) " +
                            "VALUES('" + btitle + "', '" + bauthor + "', " + byear + ");";

                    myDB.execSQL(sql);


                    //tv.setText(sql);
                    myDB.close();
                }   catch (Exception e) {
                    tv.setText("OOPs something is wrong");

                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void addBook(View v){
        // Get user data and store in the database as a new record
        // assuming the database already exists so don't need CREATE TABLE

    }

    @Override
    public void onClick(View v) {

    }
}