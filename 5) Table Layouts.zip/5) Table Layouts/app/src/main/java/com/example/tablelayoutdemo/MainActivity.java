package com.example.tablelayoutdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void get_rating(View v){
        RatingBar x = (RatingBar) findViewById(R.id.ratingBar);
        float rating = x.getRating();
        TextView checkit = (TextView) findViewById(R.id.rating_info);
        checkit.setText("Rating is " + rating + " stars");
    }

}