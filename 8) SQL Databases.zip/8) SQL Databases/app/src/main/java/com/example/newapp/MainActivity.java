package com.example.newapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void saveInfo(View v){
        EditText nametxt = (EditText) findViewById(R.id.username);
        String uname = nametxt.getText().toString();

        EditText agetxt = (EditText) findViewById(R.id.userage);
        String agestr = agetxt.getText().toString();
        int uage = Integer.parseInt(agestr);

        // Save as shared preferences
        // Define filename and location

        String spf = getPackageName() + "prefs";
        SharedPreferences sp = getSharedPreferences(spf, MODE_PRIVATE);
        SharedPreferences.Editor myEditor = sp.edit();

        // now have a Shared preferences editor object associated with physical file
        // So can store/save data

        myEditor.putString("name", uname);
        myEditor.putInt("age:", uage);
        myEditor.commit();
    }

    public void nextApp(View v){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    public void addBook(View v){
        Intent intent = new Intent(this, Bookadd.class);
        startActivity(intent);
    }

}