package com.example.newapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView tv = (TextView) findViewById(R.id.displayprefs);
        // Retrieve the shared prefs data for display
        String spf = getPackageName() + "prefs";
        SharedPreferences sp = getSharedPreferences(spf, MODE_PRIVATE);
        String username = sp.getString("name", "dummy");
        int age = sp.getInt("age", 0);
        tv.setText("Hi " + username + " glad to hear you are " + age);

        String dbinfo = "";

        try{
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase("/data/data/" + getPackageName() +
                    "/databases/simplebooks1.db", null, SQLiteDatabase.OPEN_READONLY);
            String sql = "SELECT * FROM booksimple;";
            Cursor crs = myDB.rawQuery(sql, null);
            if (crs.moveToFirst()){
                do{
                    dbinfo += crs.getString(0) + "\n" +
                    crs.getString(1) + "\n" +
                    crs.getInt(2) + "\n\n";
                } while (crs.moveToNext());

                //SUPER IMPORTANT
                myDB.close();
            }

            TextView tv2 = (TextView) findViewById(R.id.displaydb);
            tv2.setText(dbinfo);
        } catch (SQLiteException e){
            e.printStackTrace();
            TextView tv2 = (TextView) findViewById(R.id.displaydb);
            tv2.setText("Oh-no something is wrong!");
        }
    }
}