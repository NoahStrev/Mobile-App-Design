package com.example.newapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Bookadd extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookadd);
    }
    public void addBook(View v){
        SQLiteDatabase myDB = null;
        String TableName = "booksimple";
        String insertSQL = "000";
        TextView tv = (TextView) findViewById(R.id.result);

        try {
            myDB = this.openOrCreateDatabase("simplebooks.db", Context.MODE_PRIVATE, null);

            // CREATE THE TABLE IF NECESSARY
            myDB.execSQL("CREATE TABLE IF NOT EXISTS " + TableName +
                    " (Title VARCHAR, Author VARCHAR, Year INT); ");

            // Add the info from the screen

            EditText btitle = (EditText) findViewById(R.id.booktitle);
            EditText bauthor = (EditText) findViewById(R.id.bookauthor);
            EditText byear = (EditText) findViewById(R.id.bookYear);
            String bt = btitle.getText().toString();
            String ba = bauthor.getText().toString();
            String by = byear.getText().toString();
            int bookyear = Integer.parseInt(by);

            insertSQL = "INSERT INTO " + TableName +
                        " (Title, Author, Year)" +
                        " VALUES('" + bt + "','" + ba + "'," + bookyear + ");";
            tv.setText(insertSQL);
            // Once this looks accurate we will insert the record
            myDB.execSQL(insertSQL);

            myDB.close();

        } catch (SQLiteException e){
            tv.setText("Troubles");
        }
    }

    public void goBack(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}