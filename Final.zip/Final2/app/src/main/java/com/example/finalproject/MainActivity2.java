package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void goBack(View v){
        Intent prevActivity = new Intent(this,MainActivity.class);
        startActivity(prevActivity);
    }

    public void chartPunt(View v){
        TextView tv = (TextView) findViewById(R.id.result);

        EditText hang = (EditText) findViewById(R.id.hangtimeVal);
        String hangVal = hang.getText().toString();
        double hangtime = Double.parseDouble(hangVal);

        EditText dist = (EditText) findViewById(R.id.distanceVal);
        String distVal = dist.getText().toString();
        int distance = Integer.parseInt(distVal);

        EditText ret = (EditText) findViewById(R.id.returnVal);
        String retVal = ret.getText().toString();
        int returnYards = Integer.parseInt(retVal);

        try{
            //tv.setText("Inside");
            SQLiteDatabase myAddDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/punting.db",
                    null,
                    SQLiteDatabase.OPEN_READWRITE);

            //tv.setText("Working");

            String insertSQL = "INSERT INTO puntingdata (hangtime, distance, returnyards) " + " VALUES (" + hangtime + "," + distance + "," + returnYards + ");" ;

            myAddDB.execSQL(insertSQL);

            tv.setText("Charted!");

        } catch (Exception e) {
            tv.setText("OOPs something is wrong");
        }
        /*
        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() + "/databases/exercises.sqlite",
                    null,
                    SQLiteDatabase.OPEN_READONLY);

            String query = "SELECT " + selectedRadioButton + " FROM activities WHERE exerciseactivity LIKE '" + selectedAct + "' ;";

            tv.setText(query);

            Cursor crs = myDB.rawQuery(query, null);

            if(crs.moveToFirst()) {
                do {
                    calories = crs.getDouble(0);
                } while (crs.moveToNext());
            }

            calories = calories * (minutesVal/10);

            tv.setText(calories + "");

            myDB.close();
        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");
        }

         */


    }
}