package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        DecimalFormat f = new DecimalFormat("###.00");

        TextView tv = (TextView) findViewById(R.id.puntAvg);
        TextView tv2 = (TextView) findViewById(R.id.longPunt);
        TextView tv3 = (TextView) findViewById(R.id.shortPunt);
        TextView tv4 = (TextView) findViewById(R.id.netPunt);
        TextView tv5 = (TextView) findViewById(R.id.avgHang);
        TextView tv6 = (TextView) findViewById(R.id.highHang);
        TextView tv7 = (TextView) findViewById(R.id.lowHang);
        TextView tv8 = (TextView) findViewById(R.id.longReturn);
        TextView tv9 = (TextView) findViewById(R.id.avgReturn);
        TextView tv10 = (TextView) findViewById(R.id.percent);
        TextView tv11 = (TextView) findViewById(R.id.longMake);
        TextView tv12 = (TextView) findViewById(R.id.longAttempt);
        TextView tv13 = (TextView) findViewById(R.id.avgDistance);

        double hangtimesum = 0;
        double puntYardSum = 0;
        double returnSum = 0;

        double yardAverage = 0;
        double hangAverage = 0;
        double returnAverage = 0;
        double netAverage = 0;

        int puntCount = 0;

        double highestHang = 0;
        double lowestHang = 10;

        int farthestPunt = 0;
        int shortestPunt = 100;

        int farthestReturn = 0;

        double tempHang = 0;
        int tempYard = 0;
        int tempReturn = 0;

        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/punting.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display

            String sql = "SELECT * FROM puntingdata;";
            Cursor crs = myDB.rawQuery(sql, null);

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    //Setting temp Variables
                    tempHang = crs.getDouble(0);
                    tempYard = crs.getInt(1);
                    tempReturn = crs.getInt(2);

                    //Totaling everything
                    hangtimesum += tempHang;
                    puntYardSum += tempYard;
                    returnSum += tempReturn;

                    //Counting
                    puntCount++;

                    // Hangtime
                    if (tempHang > highestHang){
                        highestHang = tempHang;
                    }
                    if (tempHang < lowestHang){
                        lowestHang = tempHang;
                    }

                    // Yards
                    if (tempYard > farthestPunt){
                        farthestPunt = tempYard;
                    }
                    if (tempYard < shortestPunt){
                        shortestPunt = tempYard;
                    }

                    // Return
                    if (tempReturn > farthestReturn){
                        farthestReturn = tempReturn;
                    }

                } while (crs.moveToNext());
            }

            //Getting the Averages
            yardAverage = (puntYardSum / puntCount);
            hangAverage = (hangtimesum / puntCount);
            returnAverage = (returnSum / puntCount);
            netAverage = ((puntYardSum - returnSum) / puntCount);
            myDB.close();

        }   catch (Exception e) {
            tv2.setText("OOPs something is wrong");
        }

        tv.setText(f.format(yardAverage) + " Yards");
        tv2.setText(farthestPunt + " Yards");
        tv3.setText(shortestPunt + " Yards");
        tv4.setText(f.format(netAverage) + " Yards");
        tv5.setText(f.format(hangAverage) + " Seconds");
        tv6.setText(f.format(highestHang) + " Seconds");
        tv7.setText(f.format(lowestHang) + " Seconds");
        tv8.setText(farthestReturn + " Yards");
        tv9.setText(f.format(returnAverage) + " Yards");

        int kickCount = 0;

        int longMake = 0;
        int longAttempt = 0;

        double attemptDistanceAverage = 0;
        double fgPercent = 0;

        double distanceSum = 0;
        double makeSum = 0;

        int tempDistance = 0;
        int tempMake = 0;

        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/kicking.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display

            String sql = "SELECT * FROM placekicking;";
            Cursor crs = myDB.rawQuery(sql, null);

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    //Setting temp Variables
                    tempDistance = crs.getInt(0);
                    tempMake = crs.getInt(1);

                    //Totaling everything
                    distanceSum += tempDistance;
                    makeSum += tempMake;

                    //Counting
                    kickCount++;

                    // Farthest Attempt
                    if (tempDistance > longAttempt){
                        longAttempt = tempDistance;
                    }

                    // Farthest Make
                    if (tempMake == 1){
                        if (tempDistance > longMake){
                            longMake = tempDistance;
                        }
                    }

                } while (crs.moveToNext());
            }

            //Getting the Averages
            attemptDistanceAverage = (distanceSum / kickCount);
            fgPercent = (makeSum / kickCount) * 100;
            myDB.close();

        }   catch (Exception e) {
            tv2.setText("OOPs something is wrong");
        }

        tv10.setText(f.format(fgPercent) + "%");
        tv11.setText(longMake + " Yards");
        tv12.setText(longAttempt + " Yards");
        tv13.setText(f.format(attemptDistanceAverage) + " Yards");

    }

    public void goBack(View v){
        Intent prevActivity = new Intent(this,MainActivity.class);
        startActivity(prevActivity);
    }
}