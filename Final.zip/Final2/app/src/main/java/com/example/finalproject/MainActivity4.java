package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        TextView tv = (TextView) findViewById(R.id.fieldGoalOutput);
        TextView tv2 = (TextView) findViewById(R.id.puntOutput);

        String dbinfo = "";
        String dbinfo2 = "";
        String temp = "";

        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/kicking.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display

            String sql = "SELECT * FROM placekicking;";
            Cursor crs = myDB.rawQuery(sql, null);

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    if(crs.getInt(1) == 1){
                        temp = "Make";
                    }
                    else{
                        temp = "Miss";
                    }
                    dbinfo += crs.getInt(0) + " Yarder: " +
                            temp + "\n";

                } while (crs.moveToNext());
            }
            tv.setText(dbinfo);
            myDB.close();

        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");
        }

        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/punting.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display

            String sql = "SELECT * FROM puntingdata;";
            Cursor crs = myDB.rawQuery(sql, null);

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    dbinfo2 += crs.getInt(1) + " Yards, " +
                            crs.getDouble(0) + " Hangtime, "+
                            crs.getInt(2) + " Yard Return\n";

                } while (crs.moveToNext());
            }
            tv2.setText(dbinfo2);
            myDB.close();

        }   catch (Exception e) {
            tv2.setText("OOPs something is wrong");
        }
    }

    public void goBack(View v){
        Intent prevActivity = new Intent(this,MainActivity.class);
        startActivity(prevActivity);
    }
}