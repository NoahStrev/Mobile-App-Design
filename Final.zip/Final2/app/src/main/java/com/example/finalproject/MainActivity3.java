package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }

    public void goBack(View v){
        Intent prevActivity = new Intent(this,MainActivity.class);
        startActivity(prevActivity);
    }

    public void chartFieldGoal(View v){
        TextView tv = (TextView) findViewById(R.id.result2);

        EditText dist = (EditText) findViewById(R.id.distanceVal2);
        String distVal = dist.getText().toString();
        int distance = Integer.parseInt(distVal);

        Spinner attemptChoice = (Spinner) findViewById(R.id.makeOrMiss);
        String selectedAttempt = attemptChoice.getSelectedItem().toString();
        int attempt = 0;

        if (selectedAttempt.equalsIgnoreCase("Make")){
            attempt = 1;
        }
        else{
            attempt = 0;
        }

        try{
            //tv.setText("Inside");
            SQLiteDatabase myAddDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/kicking.db",
                    null,
                    SQLiteDatabase.OPEN_READWRITE);

            //tv.setText("Working");

            String insertSQL = "INSERT INTO placekicking (distance, ismade) " + " VALUES (" + distance + "," + attempt + ");" ;

            myAddDB.execSQL(insertSQL);

            tv.setText("Charted!");

        } catch (Exception e) {
            tv.setText("OOPs something is wrong");
        }

    }
}