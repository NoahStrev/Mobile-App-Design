package com.example.midtermproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcWastePercent5(View v) {

        DecimalFormat df = new DecimalFormat("##0");

        EditText userinput = (EditText) findViewById(R.id.length);
        String len = userinput.getText().toString();
        double lengthVal = Double.parseDouble(len);

        userinput = (EditText) findViewById(R.id.width);
        String wid = userinput.getText().toString();
        double widthVal = Double.parseDouble(wid);

        userinput = (EditText) findViewById(R.id.oneTile);
        String tile = userinput.getText().toString();
        double tileVal = Double.parseDouble(tile);

        double Area = (lengthVal * widthVal);

        double tilePerInch = Area / tileVal;

        tilePerInch = tilePerInch + (tilePerInch * .05);
        // display the result
        String msg = "When using 5% waste, you should get " + df.format(Math.ceil(tilePerInch)) + " tiles.";
        TextView displayResult = (TextView) findViewById(R.id.result);
        displayResult.setText(msg);
    }

    public void calcWastePercent10(View v) {

        DecimalFormat df = new DecimalFormat("##0");

        EditText userinput = (EditText) findViewById(R.id.length);
        String len = userinput.getText().toString();
        double lengthVal = Double.parseDouble(len);

        userinput = (EditText) findViewById(R.id.width);
        String wid = userinput.getText().toString();
        double widthVal = Double.parseDouble(wid);

        userinput = (EditText) findViewById(R.id.oneTile);
        String tile = userinput.getText().toString();
        double tileVal = Double.parseDouble(tile);

        double Area = (lengthVal * widthVal);

        double tilePerInch = Area / tileVal;

        tilePerInch = tilePerInch + (tilePerInch * .1);
        // display the result
        String msg = "When using 5% waste, you should get " + df.format(Math.ceil(tilePerInch)) + " tiles.";
        TextView displayResult = (TextView) findViewById(R.id.result);
        displayResult.setText(msg);
    }
}