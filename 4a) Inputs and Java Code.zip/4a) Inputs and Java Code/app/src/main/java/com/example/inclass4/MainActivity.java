package com.example.inclass4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate(View v){
        EditText userinput = (EditText) findViewById(R.id.speed);
        String speed = userinput.getText().toString();
        double speedVal = Double.parseDouble(speed);

        userinput = (EditText) findViewById(R.id.distance);
        String distance = userinput.getText().toString();
        double distanceVal = Double.parseDouble(distance);

        userinput = (EditText) findViewById(R.id.horsepower);
        String horsepower = userinput.getText().toString();
        double horsepowerVal = Double.parseDouble(horsepower);

        int time = (int) (Math.round((60 * distanceVal) / speedVal));

        int fuel = (int) (((.50 * horsepowerVal)/6.1) / 60 * time);

        // display the result
        TextView displayResult = (TextView) findViewById(R.id.result);
        String msg = "Planned trip will take " + time + " minutes and require " + fuel + " gallons of fuel";
        displayResult.setText(msg);
    }
}