package com.example.homework9.ui.gallery;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.homework9.R;
import com.example.homework9.databinding.FragmentGalleryBinding;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        GalleryViewModel galleryViewModel =
                new ViewModelProvider(this).get(GalleryViewModel.class);

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        String dbinfo = "";
        int sum = 0;
        TextView tv = (TextView) root.findViewById(R.id.previousWorkouts);
        TextView tv2 = (TextView) root.findViewById(R.id.totalCalories);
        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getActivity().getPackageName() +
                            "/databases/myactivities.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display

            String sql = "SELECT * FROM acts;";
            Cursor crs = myDB.rawQuery(sql, null);

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    dbinfo += crs.getString(0) + ":  " +
                            crs.getInt(1) + "\n";

                    sum += crs.getInt(1);
                } while (crs.moveToNext());
            }
            tv.setText(dbinfo);
            tv2.setText("Total Calories Burned: " + sum);
            myDB.close();

        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");
            tv2.setText("OOPs something is wrong");
        }
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}