package com.example.inclassreview2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Intent intentObj = getIntent();
        if (intentObj != null){
            DecimalFormat df = new DecimalFormat("##.00");
            // get data that has been passed
            String finalInput = intentObj.getStringExtra("finalInput");
            String paymentMethod = intentObj.getStringExtra("payment");
            String mainDish = intentObj.getStringExtra("maindish");
            String selectedCondiments = intentObj.getStringExtra("condiments");
            String selectedSides = intentObj.getStringExtra("sides");


            String imagefilename = mainDish.toLowerCase();
            ImageView image = (ImageView) findViewById(R.id.dishImage);
            int xid = getResources().getIdentifier(getPackageName() +
                    ":drawable/" + imagefilename, null, null);
            image.setImageResource(xid);

            String [] dishArray = getResources().getStringArray(R.array.maindishes);
            String [] descripFacts = getResources().getStringArray(R.array.descrips);

            TextView maindishfact = (TextView) findViewById(R.id.dishFacts);
            for (int i = 0; i < dishArray.length; i++){
                if (dishArray[i].equals(mainDish)){
                    maindishfact.setText(descripFacts[i]);
                }
            }
            TextView tv = (TextView) findViewById(R.id.finalResult);
            tv.setText(finalInput + "\n" + " a " + paymentMethod + " ");

        }
    }
}