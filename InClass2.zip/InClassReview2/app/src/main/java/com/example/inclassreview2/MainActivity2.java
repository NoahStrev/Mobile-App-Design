package com.example.inclassreview2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intentObj = getIntent();
        if (intentObj != null){
            DecimalFormat df = new DecimalFormat("##.00");
            // get data that has been passed
            String mainSelection = intentObj.getStringExtra("maindish");
            String selectedCondiments = intentObj.getStringExtra("condiments");
            String selectedSides = intentObj.getStringExtra("sides");

            RadioGroup rg = (RadioGroup) findViewById(R.id.paymentMethod);

            // display Time of day preference and locations preferences
            TextView tv = (TextView) findViewById(R.id.result);
            if (selectedSides.length() == 0) {
                tv.setText("You are ordering a " + mainSelection + " with " + selectedCondiments +
                        " and " + selectedSides);
                rg.setVisibility(View.INVISIBLE);
            }
            else {
                tv.setText("You are ordering a " + mainSelection + " with " + selectedCondiments +
                        " and " + selectedSides + " at an extra charge of $" + df.format(selectedSides.length()*5));
            }
            tv.setVisibility(View.VISIBLE);

        }
    }
    public void goBack(View v){
        Intent prevActivity = new Intent(this,MainActivity.class);
        startActivity(prevActivity);
    }

    public void finalView(View v) {

        Intent intentObj = getIntent();
        if (intentObj != null) {
            DecimalFormat df = new DecimalFormat("##.00");
            // get data that has been passed
            String mainSelection = intentObj.getStringExtra("maindish");
            String selectedCondiments = intentObj.getStringExtra("condiments");
            String selectedSides = intentObj.getStringExtra("sides");

            RadioGroup rg = (RadioGroup) findViewById(R.id.paymentMethod);
            int checkRadioButton = rg.getCheckedRadioButtonId();
            String whichRadioButton = "";

            if (checkRadioButton == R.id.cash) {
                whichRadioButton = " cash ";
            }
            else if (checkRadioButton == R.id.charge) {
                whichRadioButton = " charge ";
            }

            TextView input = (TextView) findViewById(R.id.result);
            String finalInput = input.getText().toString();

            Intent nextActivity = new Intent(this, MainActivity3.class);
            // passing info to MainActivity2

            nextActivity.putExtra("finalInput", finalInput);
            nextActivity.putExtra("payment", whichRadioButton);
            nextActivity.putExtra("maindish", mainSelection);
            nextActivity.putExtra("condiments", selectedCondiments);
            nextActivity.putExtra("sides", selectedSides);
            startActivity(nextActivity);
        }
    }
}