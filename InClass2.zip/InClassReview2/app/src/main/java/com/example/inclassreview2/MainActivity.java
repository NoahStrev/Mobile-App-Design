package com.example.inclassreview2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void takeMyOrder(View v) {
        Spinner dishChoice = (Spinner) findViewById(R.id.maindish);
        String spinnerSelectedValue = dishChoice.getSelectedItem().toString();

        CheckBox selectedCheese = (CheckBox) findViewById(R.id.cheese);
        CheckBox selectedKetchup = (CheckBox) findViewById(R.id.ketchup);
        CheckBox selectedRelish = (CheckBox) findViewById(R.id.relish);
        CheckBox selectedTomato = (CheckBox) findViewById(R.id.tomato);
        CheckBox selectedMustard = (CheckBox) findViewById(R.id.mustard);
        CheckBox selectedOnion = (CheckBox) findViewById(R.id.onion);
        String possibleCondiments = "";

        if (selectedCheese.isChecked()) {
            possibleCondiments = "cheese ";
        }
        if (selectedKetchup.isChecked()) {
            if (possibleCondiments.length() == 0) {
                possibleCondiments += "ketchup";
            } else {
                possibleCondiments += " and Ketchup";
            }
        }
        if (selectedRelish.isChecked()) {
            if (possibleCondiments.length() == 0) {
                possibleCondiments += "relish";
            } else {
                possibleCondiments += " and relish";
            }
        }
        if (selectedTomato.isChecked()) {
            if (possibleCondiments.length() == 0) {
                possibleCondiments += "tomato";
            } else {
                possibleCondiments += " and tomato";
            }
        }
        if (selectedMustard.isChecked()) {
            if (possibleCondiments.length() == 0) {
                possibleCondiments += "mustard";
            } else {
                possibleCondiments += " and mustard";
            }
        }
        if (selectedOnion.isChecked()) {
            if (possibleCondiments.length() == 0) {
                possibleCondiments += "onion";
            } else {
                possibleCondiments += " and onion";
            }
        }
        if (possibleCondiments.length() == 0) {
            possibleCondiments += "no condiments(s) were selected";
        }

        CheckBox selectedFries = (CheckBox) findViewById(R.id.fries);
        CheckBox selectedFruit = (CheckBox) findViewById(R.id.fruit);
        CheckBox selectedChips = (CheckBox) findViewById(R.id.chips);
        String possibleSides = "";

        if (selectedFries.isChecked()) {
            possibleSides = "Selected side(s) is/are Fries";
        }
        if (selectedFruit.isChecked()) {
            if (possibleSides.length() == 0) {
                possibleSides += "Selected side(s) is/are Fruit";
            } else {
                possibleSides += " and Fruit";
            }
        }
        if (selectedChips.isChecked()) {
            if (possibleSides.length() == 0) {
                possibleSides += "Selected side(s) is/are Chips";
            } else {
                possibleSides += " and Chips";
            }
        }
        if (possibleSides.length() == 0) {
            possibleSides += "No side(s) were selected";
        }

        // Pass the user selections to the next activity
        Intent nextActivity = new Intent(this, MainActivity2.class);
        // passing info to MainActivity2

        nextActivity.putExtra("maindish", spinnerSelectedValue);
        nextActivity.putExtra("condiments", possibleCondiments);
        nextActivity.putExtra("sides", possibleSides);
        startActivity(nextActivity);

    }
}