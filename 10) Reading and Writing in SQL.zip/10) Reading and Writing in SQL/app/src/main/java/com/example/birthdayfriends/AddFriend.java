package com.example.birthdayfriends;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class AddFriend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);
    }

    public void savefriend(View v) {

        /* *********************************************************************** */
// Create the database if it does not already exist:
        SQLiteDatabase myDB = null;
        String TableName = "friends";
        String insertSQL = "OOO";
        TextView r = (TextView) findViewById(R.id.debugging);
        EditText fname = (EditText) findViewById(R.id.firstname);
        String firstname = fname.getText().toString();
        EditText lname = (EditText) findViewById(R.id.lastname);
        String lastname = lname.getText().toString();
        EditText birthday = (EditText) findViewById(R.id.bday);
        String bbday = birthday.getText().toString();
        int bdayday = Integer.parseInt(bbday);
        EditText favoritec = (EditText) findViewById(R.id.favcolor);
        String favcolor = favoritec.getText().toString();
        Spinner mspin= (Spinner) findViewById(R.id.bmonth);
        int selectedMonth = mspin.getSelectedItemPosition() + 1;

        /* Create the Database if it does not exist. */
        try {
            r.setText("got here 0");
            myDB = openOrCreateDatabase("friendsbdays.db", MODE_PRIVATE, null);

            r.setText("got here 1");

            /* Create a Table in the Database. */
            myDB.execSQL("CREATE TABLE IF NOT EXISTS "
                    + TableName
                    + " (FirstName VARCHAR, " +
                    "LastName VARCHAR, " +
                    "Month INT," +
                    "Day INT, " +
                    "FavColor VARCHAR, " +
                    "PastGifts VARCHAR);");
            r.setText("got here 2");
            /* add the new friend to the database - note not checking for duplicates */
            insertSQL = "INSERT INTO "
                    + TableName
                    + " (FirstName, LastName, Month, Day, FavColor, PastGifts)"
                    + " VALUES ('" + firstname + "', '" + lastname + "',"
                    + selectedMonth + ", " + bdayday + ", '" + favcolor + "',' ');";
            r.setText("insertSQL is " + insertSQL);
            // now that the SQL looks good, add the friend to the database
            myDB.execSQL(insertSQL);
            r.setText("Friend has been added to the database");
            myDB.close();

        } catch (Exception e) {
            r.setText("OOPs something is wrong");
        }
    }

}






