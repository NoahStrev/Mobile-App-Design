package com.example.birthdayfriends;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ListOneFriend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_one_friend);
    }
    public void showfriend (View v) {
        EditText myfriend = (EditText) findViewById(R.id.fname);
        String whichfriend = myfriend.getText().toString();
        String dbinfo = "";
        TextView tv = (TextView) findViewById(R.id.display);
        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/friendsbdays.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display for whichfriend
            String sql = "SELECT * FROM friends WHERE FirstName LIKE '" + whichfriend + "';";
            tv.setText(sql);
           Cursor crs = myDB.rawQuery(sql, null);
            String month;
            int monthnum;

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    monthnum = crs.getInt(2) - 1;
                    String[] monthsArray = getResources().getStringArray(R.array.months);
                    month = monthsArray[monthnum];
                    dbinfo += crs.getString(0) + "  " +
                            crs.getString(1) + "  " +
                            month + " " + crs.getInt(3) + "  " +
                            crs.getString(4) + "  " +
                            crs.getString(5) + "\n\n";
                } while (crs.moveToNext());
            }
            tv.setText(dbinfo);


            myDB.close();
        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");

        }

    }
}















