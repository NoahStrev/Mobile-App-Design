package com.example.birthdayfriends;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);
        // check to see if shared prefs exist and if so use them
        String spf = getPackageName() + "colorprefs";
        SharedPreferences sp = getSharedPreferences(spf, MODE_PRIVATE);
        String colorValue = sp.getString("backcolor", "none");
        if (! colorValue.equals("none")) {
            String tcolor = sp.getString("textcolor", "red");
            enactUserPrefs(this.getCurrentFocus(), tcolor, colorValue);
        }


    }

    public void changecolor(View v) {
        String spf = getPackageName() + "colorprefs";
        SharedPreferences sp = getSharedPreferences(spf, MODE_PRIVATE);
        SharedPreferences.Editor myEditor = sp.edit();

        // get spinner color preferences
        Spinner textColor = (Spinner) findViewById(R.id.textcolor);
        String tcolor = textColor.getSelectedItem().toString();
        myEditor.putString("textcolor", tcolor);
        Spinner backcolor = (Spinner) findViewById(R.id.backcolor);
        String bcolor = backcolor.getSelectedItem().toString();
        myEditor.putString("backcolor", bcolor);
        myEditor.commit();

       enactUserPrefs(v, tcolor, bcolor);
    }

    public void enactUserPrefs(View v, String tcolor, String bcolor) {
        TextView tc = (TextView) findViewById(R.id.tc);
        TextView bc = (TextView) findViewById(R.id.bc);
        TextView hdr = (TextView) findViewById(R.id.hdr);
        tc.setTextColor(Color.parseColor(tcolor));
        bc.setTextColor(Color.parseColor(tcolor));
        hdr.setTextColor(Color.parseColor(tcolor));
        Button changecolor = (Button) findViewById(R.id.colorbtn);
        changecolor.setText("You may change colors");
        ConstraintLayout myScreen = (ConstraintLayout) findViewById(R.id.screen);
        myScreen.setBackgroundColor(Color.parseColor(bcolor));
        Button btn2 = (Button) findViewById(R.id.button2);
        Button btn3 = (Button) findViewById(R.id.button3);
        Button btn4 = (Button) findViewById(R.id.button4);
        Button btn5 = (Button) findViewById(R.id.button5);
        Button btn6 = (Button) findViewById(R.id.button6);
        btn2.setVisibility(View.VISIBLE);
        btn3.setVisibility(View.VISIBLE);
        btn4.setVisibility(View.VISIBLE);
        btn5.setVisibility(View.VISIBLE);
        btn6.setVisibility(View.VISIBLE);
    }

    public void listall(View v) {
        Intent golist = new Intent(this, ListAll.class);
        startActivity(golist);
    }

    public void addfriend(View v) {
        Intent golist = new Intent(this, AddFriend.class);
        startActivity(golist);
    }

    public void listonefriend(View v) {
        Intent golist = new Intent(this, ListOneFriend.class);
        startActivity(golist);
    }

}
















