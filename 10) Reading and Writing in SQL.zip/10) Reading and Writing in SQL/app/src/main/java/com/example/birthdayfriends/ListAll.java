package com.example.birthdayfriends;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.widget.TextView;

public class ListAll extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_all);

        String dbinfo = "";
        TextView tv = (TextView) findViewById(R.id.displayinfo);
        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() +
                            "/databases/friendsbdays.db",
                    null,
                    SQLiteDatabase.OPEN_READONLY);
            // now get data to display
            String sql = "SELECT * FROM friends;";
            Cursor crs = myDB.rawQuery(sql, null);
            String month;
            int monthnum;

            if (crs.moveToFirst()) {
                // ok database has records
                do {
                    monthnum = crs.getInt(2) - 1;
                    String[] monthsArray = getResources().getStringArray(R.array.months);
                    month = monthsArray[monthnum];
                    dbinfo += crs.getString(0) + "  " +
                            crs.getString(1) + "  " +
                            month + " " + crs.getInt(3) + "  " +
                            crs.getString(4) + "  " +
                            crs.getString(5) + "\n\n";
                } while (crs.moveToNext());
            }
            tv.setText(dbinfo);
            myDB.close();
        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");

        }

    }
}









