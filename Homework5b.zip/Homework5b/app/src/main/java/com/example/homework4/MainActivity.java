package com.example.homework4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void bookMyTrip(View v){
        Spinner wonderChoice = (Spinner) findViewById(R.id.chosenwonder);
        String spinnerSelectedValue = wonderChoice.getSelectedItem().toString();

        double cost = 0;

        RadioGroup rgTime = (RadioGroup) findViewById(R.id.lengthOfTime);
        int checkRadioButtonTime = rgTime.getCheckedRadioButtonId();
        String whichRadioButtonTime = "";
        if (checkRadioButtonTime == R.id.fourDays){
            whichRadioButtonTime = "four days";
        }
        else if(checkRadioButtonTime == R.id.one_week){
            whichRadioButtonTime = "one week";
            cost += 1200;
        }
        else if(checkRadioButtonTime == R.id.two_weeks){
            whichRadioButtonTime = "two weeks";
            cost += 4000;
        }
        else if(checkRadioButtonTime == R.id.one_month){
            whichRadioButtonTime = "one month";
            cost += 9600;
        }

        RadioGroup rgPackages = (RadioGroup) findViewById(R.id.packages);
        int checkRadioButtonPackages = rgPackages.getCheckedRadioButtonId();
        String whichRadioButtonPackages = "";
        if (checkRadioButtonPackages == R.id.standard){
            whichRadioButtonPackages = "standard";
            cost += 3000;
        }
        else if(checkRadioButtonPackages == R.id.deluxe){
            whichRadioButtonPackages = "deluxe";
            cost += 5000;
        }
        else if(checkRadioButtonPackages == R.id.first_class){
            whichRadioButtonPackages = "first class";
            cost += 7000;
        }

        CheckBox locationAir = (CheckBox) findViewById(R.id.air);
        CheckBox locationWater = (CheckBox) findViewById(R.id.airAndWater);
        String possibleModes = "";

        if (locationAir.isChecked()){
            possibleModes = "air";
        }
        if (locationWater.isChecked()){
            if(possibleModes.length() == 0){
                possibleModes += "air and water";
            }
            else{
                possibleModes += " and water";
            }
            cost += 2500;
        }
        if(possibleModes.length() == 0){
            possibleModes += "no possible mode of travel were selected";
        }

        Intent nextActivity = new Intent(this, MainActivity3.class);
        // passing info to MainActivity2

        nextActivity.putExtra("wondername", spinnerSelectedValue);
        nextActivity.putExtra("radiobuttontime", whichRadioButtonTime);
        nextActivity.putExtra("radiobuttonpackages", whichRadioButtonPackages);
        nextActivity.putExtra("travelmodes", possibleModes);
        nextActivity.putExtra("cost", cost);
        startActivity(nextActivity);
    }

    public void moreDetails(View v){
        Spinner wonderChoice = (Spinner) findViewById(R.id.chosenwonder);
        String spinnerSelectedValue = wonderChoice.getSelectedItem().toString();

        RadioGroup rgTime = (RadioGroup) findViewById(R.id.lengthOfTime);
        int checkRadioButtonTime = rgTime.getCheckedRadioButtonId();
        String whichRadioButtonTime = "";
        if (checkRadioButtonTime == R.id.fourDays){
            whichRadioButtonTime = "Four Days";
        }
        else if(checkRadioButtonTime == R.id.one_week){
            whichRadioButtonTime = "One Week";
        }
        else if(checkRadioButtonTime == R.id.two_weeks){
            whichRadioButtonTime = "Two Weeks";
        }
        else if(checkRadioButtonTime == R.id.one_month){
            whichRadioButtonTime = "One Month";
        }

        RadioGroup rgPackages = (RadioGroup) findViewById(R.id.packages);
        int checkRadioButtonPackages = rgPackages.getCheckedRadioButtonId();
        String whichRadioButtonPackages = "";
        if (checkRadioButtonPackages == R.id.standard){
            whichRadioButtonPackages = "Standard";
        }
        else if(checkRadioButtonPackages == R.id.deluxe){
            whichRadioButtonPackages = "Deluxe";
        }
        else if(checkRadioButtonPackages == R.id.first_class){
            whichRadioButtonPackages = "First Class";
        }

        CheckBox locationAir = (CheckBox) findViewById(R.id.air);
        CheckBox locationWater = (CheckBox) findViewById(R.id.airAndWater);
        String possibleModes = "";

        if (locationAir.isChecked()){
            possibleModes = "Possible mode of travel is Air ";
        }
        if (locationWater.isChecked()){
            if(possibleModes.length() == 0){
                possibleModes += "Possible mode of travel is Air and Water";
            }
            else{
                possibleModes += " and Water";
            }
        }
        if(possibleModes.length() == 0){
            possibleModes += "No possible mode of travel were selected";
        }

        Intent nextActivity = new Intent(this, MainActivity2.class);
        // passing info to MainActivity2

        nextActivity.putExtra("wondername", spinnerSelectedValue);
        startActivity(nextActivity);
    }
}