package com.example.homework4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Intent intentObj = getIntent();
        if (intentObj != null) {
            DecimalFormat df = new DecimalFormat("##,##0.00");

            // get data that has been passed
            String wonderSelection = intentObj.getStringExtra("wondername");
            String lengthOfStay = intentObj.getStringExtra("radiobuttontime");
            String selectedPackage = intentObj.getStringExtra("radiobuttonpackages");
            String selectedTravelMode = intentObj.getStringExtra("travelmodes");
            double totalPrice = intentObj.getDoubleExtra("cost", 0);

            String imagefilename = wonderSelection.toLowerCase();
            imagefilename = imagefilename.replaceAll("\\s", "");
            ImageView wonderimage = (ImageView) findViewById(R.id.finalImage);
            int xid = getResources().getIdentifier(getPackageName() +
                    ":drawable/" + imagefilename, null, null);
            wonderimage.setImageResource(xid);

            // display Time of day preference and locations preferences
            TextView tv = (TextView) findViewById(R.id.finalHeader);
            tv.setText("You are going to the " + wonderSelection + "!");

            TextView tv2 = (TextView) findViewById(R.id.finalOutput);
            tv2.setText("Your selected mode of travel is " + selectedTravelMode + ". You are going for "
                + lengthOfStay + " with the " + selectedPackage + " package after you have paid us $" + df.format(Math.ceil(totalPrice)));
        }
    }
}