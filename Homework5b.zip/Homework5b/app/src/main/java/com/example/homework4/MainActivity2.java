package com.example.homework4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intentObj = getIntent();
        if (intentObj != null) {
            // get data that has been passed
            String wonderSelection = intentObj.getStringExtra("wondername");

            String imagefilename = wonderSelection.toLowerCase();
            imagefilename = imagefilename.replaceAll("\\s", "");
            ImageView wonderimage = (ImageView) findViewById(R.id.wonderImage);
            int xid = getResources().getIdentifier(getPackageName() +
                    ":drawable/" + imagefilename, null, null);
            wonderimage.setImageResource(xid);

            String[] wonderArray = getResources().getStringArray(R.array.wonders);
            String[] wonderFacts = getResources().getStringArray(R.array.destdescrips);

            TextView tvmonthfact = (TextView) findViewById(R.id.funFacts);
            for (int i = 0; i < wonderArray.length; i++) {
                if (wonderArray[i].equals(wonderSelection)) {
                    tvmonthfact.setText(wonderFacts[i]);
                }
            }

            // display Time of day preference and locations preferences
            TextView tv = (TextView) findViewById(R.id.header);
            tv.setText("Destination: " + wonderSelection);
        }
    }

        public void goBack(View v){
            Intent prevActivity = new Intent(this,MainActivity.class);
            startActivity(prevActivity);
        }
}