package com.example.homework2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate(View v) {

        DecimalFormat df = new DecimalFormat("###.0");

        EditText userinput = (EditText) findViewById(R.id.rmv);
        String rmv = userinput.getText().toString();
        double rmvVal = Double.parseDouble(rmv);

        userinput = (EditText) findViewById(R.id.tank_volume);
        String tank = userinput.getText().toString();
        double tankVal = Double.parseDouble(tank);

        userinput = (EditText) findViewById(R.id.sap);
        String sap = userinput.getText().toString();
        double sapVal = Double.parseDouble(sap);

        userinput = (EditText) findViewById(R.id.depth);
        String depth = userinput.getText().toString();
        double depthVal = Double.parseDouble(depth);

        userinput = (EditText) findViewById(R.id.reserve);
        String reserve = userinput.getText().toString();
        double reserveVal = Double.parseDouble(reserve);

        double sac = rmvVal / tankVal;

        double pressure = ((depthVal * 0.3046) / 10) + 1;

        double consumption = sac * pressure;

        double available = sapVal - reserveVal;

        double time = available / consumption;

        // display the result
        TextView displayResult = (TextView) findViewById(R.id.result);
        String msg = "Answer: " + df.format(time) + " minutes";
        displayResult.setText(msg);
        displayResult.setBackgroundColor(Color.BLACK);
    }
}
