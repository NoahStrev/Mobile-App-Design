package com.example.dynamiccontent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void getinfo(View v){
        int arraySubscript;

        // which button got us here?
        int id = v.getId();

        // was it divingducks? mallards?
        if(id == R.id.divingducks) arraySubscript = 0;
        else if(id == R.id.mallards) arraySubscript = 1;
        else arraySubscript = 2;

        // now we know which string array element we need to display
        // go get the string array information from strings.xml
        String [] ducksGenres = getResources().getStringArray(R.array.ducktypes);
        String [] ducksDescriptions = getResources().getStringArray(R.array.ducksinfo);

        // set up output display
        String displayThis = ducksGenres[arraySubscript] + "\n\n" + ducksDescriptions[arraySubscript];
        TextView tv = (TextView) findViewById(R.id.displayinfo);
        tv.setText(displayThis);
    }
}