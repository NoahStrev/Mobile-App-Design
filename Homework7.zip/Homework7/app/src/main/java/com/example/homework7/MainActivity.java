package com.example.homework7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String spf = getPackageName() + "prefs";
        SharedPreferences sp = getSharedPreferences(spf, MODE_PRIVATE);
        String username = sp.getString("name:", "");
        if(!username.equals("")){
            TextView tv = (TextView) findViewById(R.id.namePrompt);
            tv.setText("Hello " + username + "!");
            EditText nametxt = (EditText) findViewById(R.id.name);
            nametxt.setVisibility(View.INVISIBLE);
        }
    }

    public void recordActivity(View v) {
        Intent nextActivity = new Intent(this,MainActivity2.class);
        startActivity(nextActivity);
    }

    public void displayActivity(View v) {
        String spf = getPackageName() + "prefs";
        SharedPreferences sp = getSharedPreferences(spf, MODE_PRIVATE);
        SharedPreferences.Editor myEditor = sp.edit();

        EditText nametxt = (EditText) findViewById(R.id.name);
        String uname = nametxt.getText().toString();
        myEditor.putString("name:", uname);
        myEditor.commit();

        TextView tv = (TextView) findViewById(R.id.testOutput);
        tv.setText(uname);
    }

}