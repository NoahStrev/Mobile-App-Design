package com.example.homework7;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void recordThis(View v){
        TextView tv = (TextView) findViewById(R.id.result);
        EditText userinput = (EditText) findViewById(R.id.minutes);
        String minutesString = userinput.getText().toString();
        double minutesVal = Double.parseDouble(minutesString);

        do{
            if(minutesVal <= 0){
                userinput = (EditText) findViewById(R.id.minutes);
                minutesString = userinput.getText().toString();
                minutesVal = Double.parseDouble(minutesString);
                tv.setText("Please input a positive integer");
            }
        }while(minutesVal <= 0);

        Spinner actChoice = (Spinner) findViewById(R.id.activitiesSpinner);
        String selectedAct = actChoice.getSelectedItem().toString();

        RadioGroup rgTime = (RadioGroup) findViewById(R.id.weight);
        int checkRadioButtonTime = rgTime.getCheckedRadioButtonId();

        String selectedRadioButton = "";
        if (checkRadioButtonTime == R.id.onetwentyfour){
            selectedRadioButton = "lbs124";
        }
        else if(checkRadioButtonTime == R.id.onefifty){
            selectedRadioButton = "lbs150";
        }
        else if(checkRadioButtonTime == R.id.oneseventyfive){
            selectedRadioButton = "lbs175";
        }
        else if(checkRadioButtonTime == R.id.twohundred){
            selectedRadioButton = "lbs200";
        }
        else if(checkRadioButtonTime == R.id.twofifty){
            selectedRadioButton = "lbs250";
        }

        double calories = 0.0;

        try {
            SQLiteDatabase myDB = SQLiteDatabase.openDatabase(
                    "/data/data/" + getPackageName() + "/databases/exercises.sqlite",
                    null,
                    SQLiteDatabase.OPEN_READONLY);


            String query = "SELECT " + selectedRadioButton + " FROM activities WHERE exerciseactivity LIKE '" + selectedAct + "' ;";

            tv.setText(query);

            Cursor crs = myDB.rawQuery(query, null);

            if(crs.moveToFirst()) {
                do {
                    calories = crs.getDouble(0);
                } while (crs.moveToNext());
            }

            calories = calories * (minutesVal/10);

            tv.setText(calories + "");

            myDB.close();
        }   catch (Exception e) {
            tv.setText("OOPs something is wrong");
        }
    }
}