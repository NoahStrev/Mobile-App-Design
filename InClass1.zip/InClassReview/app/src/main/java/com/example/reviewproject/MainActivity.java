package com.example.reviewproject;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate(View v) {

        EditText userinput = (EditText) findViewById(R.id.Barometric);
        String bar = userinput.getText().toString();
        double barVal = Double.parseDouble(bar);

        userinput = (EditText) findViewById(R.id.Envelope);
        String env = userinput.getText().toString();
        double envVal = Double.parseDouble(env);

        userinput = (EditText) findViewById(R.id.Air);
        String air = userinput.getText().toString();
        double airVal = Double.parseDouble(air);

        userinput = (EditText) findViewById(R.id.Lift);
        String lift = userinput.getText().toString();
        double liftVal = Double.parseDouble(lift);

        double pascals = barVal * 3386.38866667;

        double volume = envVal * 0.0283168;

        double temperature = (airVal + 459.67) * (5.0/9.0);

        double payload = liftVal * 0.453592;

        double dryAir = 287.058;

        double envelopeTemperature =  (((pascals * volume) / dryAir) / ( (pascals * volume) / (dryAir * temperature) - payload));

        envelopeTemperature = (int) ((envelopeTemperature / (5.0/9.0)) - 459.67);
        String msg = "";
        // display the result
        if(envelopeTemperature > 490){
            msg = "DANGER!!! SHED LBS!!! DANGER!!! TOO HOT!!!";
        }
        else {
            msg = envelopeTemperature + " DEGREES IS REQUIRED ENV TEMPERATURE!";
        }
        TextView displayResult = (TextView) findViewById(R.id.result);
        displayResult.setText(msg);
    }
}