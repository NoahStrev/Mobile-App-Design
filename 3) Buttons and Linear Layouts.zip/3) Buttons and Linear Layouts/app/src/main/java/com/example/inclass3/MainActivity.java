package com.example.inclass3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void convertCelsius(View v){
        //Retrieve the user value and assume its Fahrenheit to be converted to Celsius
        EditText userinput = (EditText) findViewById(R.id.user_input);
        String inputVal = userinput.getText().toString();
        // convert the sting input to a double
        double tempVal = Double.parseDouble(inputVal);
        // convert to Celsius
        double celsiusEquiv = (tempVal - 32) * 5.0/9.0;

        // display the result
        TextView displayResult = (TextView) findViewById(R.id.result);
        String msg = "Celsius equivalent is " + celsiusEquiv;
        displayResult.setText(msg);
    }

    public void convertFahrenheit(View v){
        //Retrieve the user value and assume its Celsius to be converted to Fahrenheit
        EditText userinput = (EditText) findViewById(R.id.user_input);
        String inputVal = userinput.getText().toString();
        // convert the sting input to a double
        double tempVal = Double.parseDouble(inputVal);
        // convert to Celsius
        double fahrenheitEquiv = (tempVal * 9.0/5.0) + 32;

        // display the result
        TextView displayResult = (TextView) findViewById(R.id.result);
        String msg = "Celsius equivalent is " + fahrenheitEquiv;
        displayResult.setText(msg);
    }

}